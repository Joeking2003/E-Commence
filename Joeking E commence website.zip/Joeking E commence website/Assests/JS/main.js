

const navMenu = document.getElementById('nav-menu')
       navToggle = document.getElementById('nav-toggle')
       navClose = document.getElementById('nav-close')

if(navToggle) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.add('show-menu')
        })
} 

const cart = document.getElementById('cart')
       cartShop = document.getElementById('cart-shop')
       cartClose = document.getElementById('cart-close')

if(cartShop) {
    cartShop.addEventListener("click", () => {
        cart.classList.add('show-cart')
    })
}       


if(cartClose) {
    cartClose.addEventListener("click", () => {
        cart.classList.remove('show-cart')
    })
}      

    var homeSwiper = new Swiper (".home_swiper", {
        spaceBetween: 30,
        loop: 'true',
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        }
    });

function scrollHeader(){
    const header = document.getElementById('header')
    if(this.scrollY >= 50) header.classlist.add('scroll-header'); else header.classlist.remove('scroll-header')
}    

window.addEventListener('scroll', scrollHeader);

var newSwiper = new Swiper(".new_swiper", {
    spaceBetween: 5, 
    centeredSlides: true, 
    slidesPerView: 3, 
    loop: true, 
    pagination: {
        el: ".swiper-pagination", 
        clickable: true, 
    },
    breakpoints: { 
        320: { 
            slidesPerView: 1, 
            spaceBetween: 5,
        },
        768: { 
            slidesPerView: 2, 
            spaceBetween: 10,
        },
        1024: { 
            slidesPerView: 3, 
            spaceBetween: 15,
        },
    },
});


const login = document.getElementById('login')
       loginButton = document.getElementById('login-button')
       loginClose = document.getElementById('login-close')

if(loginButton) {
    loginButton.addEventListener("click", () => {
        login.classList.add('show-login')
    })
}       

if(loginClose) {
    loginClose.addEventListener("click", () => {
        login.classList.remove('show-login')
    })
}      

function scrollup(){
    const scrollup = document.getElementById('scroll-up');
    if(this.scrollY >= 350) scrollup.classList.add('show-scroll'); else scrollup.classList.remove('show-scroll')
}

window.addEventListener('scroll', scrollup)


// JS for shop


const platformFilter = document.getElementById('platformFilter');
const shopCards = document.querySelectorAll('.shop_card');

platformFilter.addEventListener('change', () => {
    const selectedPlatform = platformFilter.value;

    shopCards.forEach(card => {
        const cardPlatform = card.getAttribute('data-platform');

        if (selectedPlatform === 'all' || cardPlatform === selectedPlatform) {
            card.style.display = 'block'; 
        } else {
            card.style.display = 'none'; 
        }
    });
});


// ... (your existing JavaScript code) ...

platformFilter.addEventListener('change', () => {
    selectedPlatform = platformFilter.value; 

    shopCards.forEach(card => {
        const cardPlatform = card.getAttribute('data-platform');

        if (selectedPlatform === 'ps4') { 
            // User is viewing PS4 section
            if (cardPlatform === 'ps4') {
                card.style.display = 'block'; 
            } else {
                card.style.display = 'none'; 
            }
        } else if (selectedPlatform === 'all') { 
            // User is viewing all platforms
            // Your existing logic for displaying all cards
        } else { 
            // User is viewing another platform
            // Your existing logic for hiding PS4 cards
        }
    });
});



const paginationLinks = document.querySelectorAll('.pagination_link');

  paginationLinks.forEach(link => {
    link.addEventListener('click', (event) => {
      event.preventDefault(); 
      const currentPage = parseInt(document.querySelector('.pagination_link.active').textContent);
      const targetPage = parseInt(link.textContent); 

      if (!isNaN(targetPage)) { 
        updatePagination(currentPage, targetPage);
      } else if (link.classList.contains('prev-page')) {
        updatePagination(currentPage, currentPage - 1);
      } else if (link.classList.contains('next-page')) {
        updatePagination(currentPage, currentPage + 1);
      }
    });
  });

  function updatePagination(currentPage, targetPage) {
    
    document.querySelector('.pagination_link.active').classList.remove('active');
    const targetLink = document.querySelector(`.pagination_link:nth-child(${targetPage + 1})`); 
    targetLink.classList.add('active'); 

   
    const shopCards = document.querySelectorAll('.shop_card'); 
    shopCards.forEach(card => card.style.display = 'none'); 

    const cardsPerPage = 3; 
    const startIndex = (targetPage - 1) * cardsPerPage;
    const endIndex = startIndex + cardsPerPage;

    for (let i = startIndex; i < endIndex; i++) {
      if (shopCards[i]) { 
        shopCards[i].style.display = 'block';
      }
    }
  }


//   registration form

const passwordFields = document.querySelectorAll('input[type="password"]');
const togglePasswordIcons = document.querySelectorAll('.toggle-password');

togglePasswordIcons.forEach((icon, index) => {
    icon.addEventListener('click', () => {
        passwordFields[index].type = 
            passwordFields[index].type === "password" ? "text" : "password";
        icon.querySelector('i').classList.toggle('bx-hide'); 
        icon.querySelector('i').classList.toggle('bx-show'); 
    });
});